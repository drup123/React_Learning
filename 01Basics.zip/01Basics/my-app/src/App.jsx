
import Trial from "./Trial"

function App() {
 

  return (
    <>                                   
    <h1>Okay let's start</h1>
    <Trial/>
    </>
  )
}

export default App
