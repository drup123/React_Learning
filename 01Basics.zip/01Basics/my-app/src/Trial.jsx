function Trial() {
    return (
        <h3>Hello I am Captain America</h3>
    )
}

export default Trial;